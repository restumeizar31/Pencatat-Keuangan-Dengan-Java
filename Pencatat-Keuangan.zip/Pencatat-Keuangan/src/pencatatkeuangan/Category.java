// File: src/pencatatkeuangan/Category.java

package pencatatkeuangan;

public sealed interface Category permits IncomeCategory, ExpenseCategory {
    String getNamaKategori();
}
