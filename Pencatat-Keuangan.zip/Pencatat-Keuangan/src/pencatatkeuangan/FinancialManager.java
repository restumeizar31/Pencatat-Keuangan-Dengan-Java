// File: src/pencatatkeuangan/FinancialManager.java

package pencatatkeuangan;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class FinancialManager {
    private double saldoAwal;
    private double saldo;
    private final ArrayList<Transaction> historiTransaksi;

    public FinancialManager(double saldoAwal) {
        this.saldoAwal = saldoAwal;
        this.saldo = saldoAwal;
        this.historiTransaksi = new ArrayList<>();
    }

    public void tambahTransaksi(Category kategori, String deskripsi, double jumlah) {
        double saldoSebelum = saldo;
        if (kategori instanceof ExpenseCategory) {
            // Pengeluaran, kurangkan saldo
            saldo -= jumlah;
        } else {
            // Pendapatan, tambahkan saldo
            saldo += jumlah;
        }
        double saldoSetelah = saldo;

        historiTransaksi.add(new Transaction(kategori, deskripsi, jumlah, saldoSebelum, saldoSetelah));
        System.out.println("Transaksi berhasil ditambahkan!");
    }

    public void tampilkanHistoriTransaksi() {
        historiTransaksi.forEach(System.out::println);
    }

    public void tampilkanTransaksi() {
        System.out.println("\nSaldo Awal: " + formatRupiah(saldoAwal));
        tampilkanHistoriPendapatanPengeluaran();
        System.out.println("Saldo Akhir: " + formatRupiah(saldo));
    }

    public double getSaldo() {
        return saldo;
    }

    public String getSaldoTerformat() {
        return formatRupiah(saldo);
    }

    private void tampilkanHistoriPendapatanPengeluaran() {
        System.out.println("\nHistori Pendapatan dan Pengeluaran:");
        historiTransaksi.forEach(transaction -> {
            Category kategori = transaction.kategori();
            String jenis = (kategori instanceof IncomeCategory) ? "Pendapatan" : "Pengeluaran";
            System.out.println("Jenis: " + jenis + ", Deskripsi: " + transaction.deskripsi() +
                    ", Jumlah: " + transaction.jumlahTerformat());
        });
    }

    private String formatRupiah(double angka) {
        NumberFormat formatAngka = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        return formatAngka.format(angka);
    }
}
