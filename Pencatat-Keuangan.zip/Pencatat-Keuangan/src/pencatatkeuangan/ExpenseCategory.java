// File: src/pencatatkeuangan/ExpenseCategory.java

package pencatatkeuangan;

public final class ExpenseCategory implements Category {
    private final String namaKategori;

    public ExpenseCategory(String namaKategori) {
        this.namaKategori = namaKategori;
    }

    @Override
    public String getNamaKategori() {
        return "Pengeluaran: " + namaKategori;
    }
}
