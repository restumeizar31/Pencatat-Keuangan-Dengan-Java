// File: src/pencatatkeuangan/Transaction.java

package pencatatkeuangan;

import java.text.NumberFormat;
import java.util.Locale;

public record Transaction(Category kategori, String deskripsi, double jumlah, double saldoSebelum, double saldoSetelah) {
    public String toString() {
        NumberFormat formatAngka = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        String jumlahTerformat = formatAngka.format(jumlah);
        String saldoSebelumTerformat = formatAngka.format(saldoSebelum);
        String saldoSetelahTerformat = formatAngka.format(saldoSetelah);

        return kategori.getNamaKategori() + " - " + deskripsi + ": " + jumlahTerformat +
                " (Saldo sebelum: " + saldoSebelumTerformat + ", Saldo setelah: " + saldoSetelahTerformat + ")";
    }

    // Metode ini untuk mendapatkan jumlah terformat sebagai String
    public String jumlahTerformat() {
        NumberFormat formatAngka = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        return formatAngka.format(jumlah);
    }
}
