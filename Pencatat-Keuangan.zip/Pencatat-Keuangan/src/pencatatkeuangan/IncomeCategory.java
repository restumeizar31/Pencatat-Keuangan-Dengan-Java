// File: src/pencatatkeuangan/IncomeCategory.java

package pencatatkeuangan;

public final class IncomeCategory implements Category {
    private final String namaKategori;

    public IncomeCategory(String namaKategori) {
        this.namaKategori = namaKategori;
    }

    @Override
    public String getNamaKategori() {
        return "Pendapatan: " + namaKategori;
    }
}
