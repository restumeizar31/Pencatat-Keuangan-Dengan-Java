// File: src/pencatatkeuangan/PersonalFinanceApp.java

package pencatatkeuangan;

import java.util.Scanner;

public class PersonalFinanceApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Group 6:");
        System.out.println("1. NI LUH ADE MEINA ROSSALINA – 2702345125");
        System.out.println("2. MUHAMMAD FIKRI DARNO – 2702384290");
        System.out.println("3. WILLIAM CHANDRA – 2702364723");
        System.out.println("4. RESTU MEIZAR - 2702365985");

        System.out.print("Masukkan saldo awal: ");
        double saldoAwal = scanner.nextDouble();
        scanner.nextLine(); // Membersihkan newline character

        FinancialManager manajerKeuangan = new FinancialManager(saldoAwal);

        while (true) {
            System.out.println("\nPersonal Finance Management System");
            System.out.println("1. Tambah Transaksi");
            System.out.println("2. Tampilkan Transaksi");
            System.out.println("3. Tampilkan Saldo");
            System.out.println("4. Keluar");
            System.out.print("Pilih opsi: ");

            int pilihan;
            try {
                pilihan = scanner.nextInt();
                scanner.nextLine(); // Membersihkan newline character
            } catch (java.util.InputMismatchException e) {
                System.out.println("Input tidak valid. Harap masukkan opsi yang valid.");
                scanner.nextLine(); // Membersihkan buffer
                continue;
            }

            switch (pilihan) {
                case 1:
                    System.out.println("\nTambah Transaksi");
                    System.out.print("Masukkan kategori (Pendapatan/Pengeluaran): ");
                    String jenisKategori = scanner.nextLine();
                    Category kategori;
                    if ("pendapatan".equalsIgnoreCase(jenisKategori)) {
                        kategori = new IncomeCategory("Gaji");
                    } else if ("pengeluaran".equalsIgnoreCase(jenisKategori)) {
                        kategori = new ExpenseCategory("Belanja");
                    } else {
                        System.out.println("Kategori tidak valid");
                        break; // keluar dari switch
                    }
                    System.out.print("Masukkan deskripsi: ");
                    String deskripsi = scanner.nextLine();
                    double jumlah;
                    try {
                        System.out.print("Masukkan jumlah: ");
                        jumlah = scanner.nextDouble();
                        scanner.nextLine(); // Membersihkan newline character
                    } catch (java.util.InputMismatchException e) {
                        System.out.println("Input tidak valid untuk jumlah. Harap masukkan angka yang valid.");
                        scanner.nextLine(); // Membersihkan buffer
                        break; // keluar dari switch
                    }
                    manajerKeuangan.tambahTransaksi(kategori, deskripsi, jumlah);
                    break;

                case 2:
                    System.out.println("\nTampilkan Transaksi");
                    manajerKeuangan.tampilkanTransaksi();
                    break;

                case 3:
                    System.out.println("\nTampilkan Saldo");
                    System.out.println("Saldo saat ini: " + manajerKeuangan.getSaldoTerformat());
                    break;

                case 4:
                    System.out.println("Keluar dari program. Selamat tinggal!");
                    System.exit(0);

                default:
                    System.out.println("Pilihan tidak valid. Harap masukkan opsi yang valid.");
            }
        }
    }
}
